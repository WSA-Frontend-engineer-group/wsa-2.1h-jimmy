import java.util.List;

public interface ChooseStrategy {
    Matching choose(List<Matching> result);
}
